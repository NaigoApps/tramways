import React from "react";

const SessionContext = React.createContext({});

export default SessionContext;
