# TramwaysApi.ActionMethod

## Enum


* `GET` (value: `"GET"`)

* `PUT` (value: `"PUT"`)

* `POST` (value: `"POST"`)

* `DELETE` (value: `"DELETE"`)


