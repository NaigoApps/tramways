# TramwaysApi.Action

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**description** | **String** |  | [optional] 
**uri** | **String** |  | [optional] 
**method** | [**ActionMethod**](ActionMethod.md) |  | [optional] 


