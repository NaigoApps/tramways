# TramwaysApi.UserRole

## Enum


* `CLIENT` (value: `"CLIENT"`)

* `EXPERT` (value: `"EXPERT"`)

* `ADMIN` (value: `"ADMIN"`)


