# TramwaysApi.ProjectAllOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**ownerURI** | **String** |  | [optional] 


