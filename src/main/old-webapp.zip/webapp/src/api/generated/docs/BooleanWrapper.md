# TramwaysApi.BooleanWrapper

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Boolean** |  | [optional] 


