# TramwaysApi.CreateProjectRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**roadmap** | **String** |  | [optional] 


