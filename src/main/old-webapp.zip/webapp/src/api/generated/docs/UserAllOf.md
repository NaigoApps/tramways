# TramwaysApi.UserAllOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** |  | [optional] 
**roles** | [**[UserRole]**](UserRole.md) |  | [optional] 


