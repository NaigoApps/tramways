import React from 'react';

export default function () {
  return (
    <div className="modal is-active">
      <div className="modal-content">
        <progress className="progress is-large is-info" max="100" />
      </div>
    </div>
  );
}
