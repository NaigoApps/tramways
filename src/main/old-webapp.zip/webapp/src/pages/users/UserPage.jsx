export default function UserPage() {
  return null;
}
