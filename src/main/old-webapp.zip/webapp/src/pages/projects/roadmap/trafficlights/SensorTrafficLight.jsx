import React from "react";

export default function SensorTrafficLight({ lane, light }) {
  return <p>{`Blocking traffic light for ${lane}`}</p>;
}
